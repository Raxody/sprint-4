package co.edu.unbosque.xtreme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XtremedefinitivoApplicationTests {

	@Test
	void contextLoads() {
	}

}
