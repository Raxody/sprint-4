package co.edu.unbosque.xtreme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XtremedefinitivoApplication {

	public static void main(String[] args) {
		SpringApplication.run(XtremedefinitivoApplication.class, args);
	}

}
